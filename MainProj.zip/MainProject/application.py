from flask import Flask, render_template, request, redirect, url_for
from flask import *
import mysql.connector
from datetime import datetime

application= Flask(__name__)
application.secret_key='abcd'


db = mysql.connector.connect(
    host="team1db.cbvckdhc0wdk.us-east-1.rds.amazonaws.com",
    user="admin",
    password="nvhr1234",
    database="onlinefoodorderingdb"
)

cursor = db.cursor(buffered=True)

@application.route('/', methods=['GET', 'POST'])
def home():
    
    return render_template("home.html")

# Home page - Login
@application.route('/adminlogin',methods=['GET', 'POST'])
def adminlogin():
    message=''
    if request.method == 'POST':
        admin_name = request.form['admin_name']
        password = request.form['password']

        query = "SELECT * FROM admindetails WHERE adminName = %s AND password = %s"
        values = (admin_name,password)
        cursor.execute(query, values)
        user = cursor.fetchone()
        
        if user:
         
            return redirect('/admindashboard')
            
        else:
         
            message="Invalid credentials"
            
          
    return render_template('admin_login.html',message=message)

@application.route('/admindashboard', methods=['GET', 'POST'])
def admindashboard():
    return render_template("admindashboard.html")
@application.route("/foodmenu",methods=["GET",'POST'])

def foodmenu():
    if request.method=='POST':
        vegornonveg=request.form['vegornonveg']
        
        query="select restuarantsdetails.restuarantname,restuarantsdetails.phoneno,restuarantsdetails.address,restuarantsdetails.openingtime,restuarantsdetails.closingtime,products.productname,products.description,products.price  from restuarantsdetails inner join products on restuarantsdetails.restuarantid=products.restuarant_id where products.vegornonveg=%s"
        
        
        cursor.execute(query,(vegornonveg,))
        #restuarants=cursor.fetchall()
        data=cursor.fetchall()
        
        return render_template("foodmenu.html",data=data)
    return render_template("food_selection.html")


#Modification Of Customers details By Admin
@application.route('/displaycustomers',methods=['GET', 'POST'])
def displaycustomers():
    cursor.execute("SELECT customerid,customername,phoneno,address,email FROM customersdetails")
    customers = cursor.fetchall()
    return render_template("customerindex.html", customers=customers)

@application.route("/editcustomer/<int:customer_id>", methods=["GET", "POST"])
def editcustomer(customer_id):
    if request.method == "POST":
        new_customername = request.form["new_customername"]
        new_phoneno = request.form["new_phoneno"]
        new_address = request.form["new_address"]
        new_email = request.form["new_email"]
        cursor.execute("UPDATE customersdetails SET customername=%s, phoneno=%s,address=%s,email=%s WHERE customerid=%s",
                       (new_customername,new_phoneno,new_address, new_email,customer_id))
        db.commit()
        return redirect("/displaycustomers")
    else:
        cursor.execute("SELECT * FROM customersdetails WHERE customerid=%s", (customer_id,))
        customer = cursor.fetchone()
        return render_template("customeredit.html", customer=customer)

@application.route("/deletecustomer/<int:customer_id>",methods=["GET", "POST"])
def deletecustomer(customer_id):
    cursor.execute("DELETE  FROM customersdetails WHERE customerid=%s", (customer_id,))
    db.commit()
    return redirect("/displaycustomers")

#Modification Of Restuarants details By Admin

@application.route('/displayrestuarants',methods=['GET', 'POST'])
def displayrestuarants():
    cursor.execute("SELECT restuarantid,restuarantname,ownername,phoneno,address FROM restuarantsdetails")
    restuarants = cursor.fetchall()
    return render_template("restuarantindex.html", restuarants=restuarants)

@application.route("/editrestuarant/<int:restuarant_id>", methods=["GET", "POST"])
def editrestuarant(restuarant_id):
    if request.method == "POST":
        new_restuarantname = request.form["new_restuarantname"]
        new_ownername = request.form["new_ownername"]
        new_phoneno = request.form["new_phoneno"]
        new_address = request.form["new_address"]
        
        cursor.execute("UPDATE restuarantsdetails SET restuarantname=%s, ownername=%s, phoneno=%s,address=%s WHERE restuarantid=%s",
                       (new_restuarantname,new_ownername,new_phoneno,new_address,restuarant_id))
        db.commit()
        return redirect("/displayrestuarants")
    else:
        cursor.execute("SELECT * FROM restuarantsdetails WHERE restuarantid=%s", (restuarant_id,))
        restuarant = cursor.fetchone()
        return render_template("restuarantedit.html", restuarant=restuarant)

@application.route("/deleterestuarant/<int:restuarant_id>",methods=["GET", "POST"])
def deleterestuarant(restuarant_id):
    cursor.execute("DELETE  FROM restuarantsdetails WHERE restuarantid=%s", (restuarant_id,))
    db.commit()
    return redirect("/displayrestuarants")



    
 
#this is code for restuarant register and  login

@application.route('/restuarantregister', methods=['GET', 'POST'])
def restuarantregister():
    message=''
    if request.method == 'POST':
        restuarant_name = request.form['restuarant_name']
        owner_name = request.form['owner_name']
        password = request.form['password']
        phone_no = request.form['phone_no']
        address = request.form['address']
        
        opening_time = request.form['opening_time']
        closing_time = request.form['closing_time']
        query = "SELECT * FROM restuarantsdetails WHERE restuarantname = %s AND ownername=%s  AND phoneno = %s AND address=%s"
        values = (restuarant_name, owner_name, phone_no,address)
        cursor.execute(query, values)
        result = cursor.fetchone()
        if not result:
            query = "INSERT INTO restuarantsdetails (restuarantName,ownername, password,phoneNo, address,openingtime,closingtime) VALUES (%s, %s, %s, %s,%s,%s,%s)"
            values = (restuarant_name,owner_name, password, phone_no, address,opening_time,closing_time)
            cursor.execute(query, values)
            db.commit()
            # message+='<html><body><center>You are succesfully registered'
            
            # message+=str(cursor.lastrowid)
            
            return redirect(url_for('restuarantlogin',message=message))
            
        else:
            message="Restuarant already Exists"
            
        
        
    
    return render_template('restuarant_register.html',message=message)
    


@application.route('/restuarantlogin', methods=['GET', 'POST'])
def restuarantlogin():
    message=''
    if request.method == 'POST':
        owner_name = request.form['owner_name']
        password = request.form['password']

        
        query = "SELECT * FROM restuarantsdetails WHERE ownername = %s AND password = %s"
        values = (owner_name,password)
        cursor.execute(query, values)
        restuarant = cursor.fetchone()
        
        if restuarant:
            session['restuarant_id']=restuarant[0]
            return redirect(url_for('restuarantdashboard'))
            
            
        else:
            message="Invalid Username or Password"

            
            
            
    return render_template('restuarant_login.html',message=message)

#HERE RESTUARANT CAN ADD/EDIT/DELETE THEIR PRODUCTS AND CAN MANAGE ORDERS ALSO
@application.route("/restuarantdashboard",methods=["GET","POST"])
def restuarantdashboard():
    return render_template('restuarantdashboard.html')

@application.route("/vieworders",methods=["GET","POST"])
def vieworders():
    
    if "restuarant_id" in session:
        restuarant_id=session['restuarant_id']
        
        
        cursor.execute("select productid,productname,customername,customerphoneno,customeraddress from orders where restuarant_id=%s",(restuarant_id,))
        orders=cursor.fetchall()
        
        return render_template('view_orders.html',orders=orders)
    return redirect(url_for('restuarantdashboard'))

@application.route("/addproducts",methods=["GET","POST"])
def addproducts():
    message=''
    restuarant_id=session.get('restuarant_id')
    if request.method == 'POST' and restuarant_id:
        
        #restuarant_id= request.form['restuarant_id']
        vegornonveg=request.form['vegornonveg']
        
        productname= request.form['productname']
        description=request.form["description"]
        price = request.form['price']

        
        query = "INSERT INTO products (restuarant_id,vegornonveg,productname,description,price) VALUES (%s,%s, %s, %s, %s)"
        values = (restuarant_id,vegornonveg,productname,description,price)
        cursor.execute(query, values)
        db.commit()
        
        return redirect("/viewproducts")
   
    return render_template("add_products.html",message=message)



@application.route("/viewproducts",methods=["GET","POST"])
def viewproducts():
    
    if "restuarant_id" in session:
        restuarant_id=session['restuarant_id']
        
        
        cursor.execute("select * from restuarantsdetails where restuarantid=%s",(restuarant_id,))
        restuarant=cursor.fetchone()
        cursor.execute("select * from products where restuarant_id=%s",(restuarant_id,))
        
        products=cursor.fetchall()
        return render_template('view_products.html',restuarant=restuarant,products=products)
    return redirect(url_for('restuarant_login'))


@application.route('/modifyproducts',methods=['GET', 'POST'])
def modifyproducts():
    restuarant_id=session.get('restuarant_id')
    if 'restuarant_id' in session:
        restuarant_id=session['restuarant_id']
        cursor.execute("SELECT productid,productname,description,price FROM products where restuarant_id=%s",(restuarant_id,))
        products = cursor.fetchall()
        return render_template("productsindex.html",products=products )

@application.route("/editproducts/<int:productid>", methods=["GET", "POST"])
def editproducts(productid):
    restuarant_id=session.get('restuarant_id')
    
    if request.method == 'POST' and restuarant_id:
        new_productname= request.form['new_productname']
        new_description=request.form["new_description"]
        new_price = request.form['new_price']
        
        cursor.execute("UPDATE products SET productname=%s, description=%s, price=%s WHERE productid=%s",
                       (new_productname,new_description,new_price,productid))
        db.commit()
        return redirect("/viewproducts")
    else:
        cursor.execute("SELECT productname,description,price FROM products WHERE productid=%s", (productid,))
        product = cursor.fetchone()
        return render_template("productsedit.html", product=product)

@application.route("/deleteproduct/<int:productid>",methods=["GET", "POST"])
def deleteproduct(productid):
    cursor.execute("DELETE  FROM products WHERE productid=%s", (productid,))
    db.commit()
    return redirect("/viewproducts")





#this is all the code of customer register and login
@application.route('/customerregister', methods=['GET', 'POST'])
def customerregister():
    message=""
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        password = request.form['password']
        phone_no = request.form['phone_no']
        address = request.form['address']
        email_id = request.form['email_id']
        query = "SELECT * FROM customersdetails WHERE customername = %s AND phoneno=%s  AND address = %s AND email=%s"
        values = (customer_name, phone_no,address,email_id)
        cursor.execute(query, values)
        result = cursor.fetchone()
        if not result:
            
            query = "INSERT INTO customersdetails (customerName, password, phoneNo, address, email) VALUES (%s, %s, %s, %s, %s)"
            values = (customer_name, password, phone_no, address, email_id)
            cursor.execute(query, values)
            db.commit()
            # message+='<html><body><center>You are succesfully registered'
            
            # message+=str(cursor.lastrowid)
            
            return redirect("/customerlogin")
        else:
            message="Account Already Exists"
        
    return render_template('customer_register.html',message=message)
    

@application.route('/customerlogin', methods=['GET', 'POST'])
def customerlogin():
    message=""
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        password = request.form['password']

        
        query = "SELECT * FROM customersdetails WHERE customerName = %s AND password = %s"
        values = (customer_name,password)
        cursor.execute(query, values)
        customer = cursor.fetchone()

        if customer:
            
            session['customerid']=customer[0]
            session['customername']=customer[1]
            session['phoneno']=customer[3]
            session['address']=customer[4]
            
            return redirect("/customerfoodmenu")
            
        else:
            message="Invalid Username or Password"
            
    return render_template('customer_login.html',message=message)
@application.route("/customerfoodmenu",methods=["GET",'POST'])

def customerfoodmenu():
    if request.method=='POST':
        vegornonveg=request.form['vegornonveg']
        current_time = datetime.now().strftime("%H:%M")
        query="select products.productid,products.restuarant_id,restuarantsdetails.restuarantname,restuarantsdetails.phoneno,restuarantsdetails.address,\
        restuarantsdetails.openingtime,restuarantsdetails.closingtime,products.productname,products.description,products.price \
                from restuarantsdetails inner join products on restuarantsdetails.restuarantid=products.restuarant_id \
                where products.vegornonveg=%s"
    
    
        cursor.execute(query,(vegornonveg,))
        
        menu=cursor.fetchall()
        
        return render_template("customerfoodmenu.html",current_time=current_time,menu=menu)
        
        
        
    return render_template("customerfoodselection.html")

    
@application.route('/order/<int:productid>', methods=['GET','POST'])
def order(productid):
    
    customerid=session["customerid"]
    cursor = db.cursor()
    cursor.execute("select productid,restuarant_id,productname from products where productid=%s",(productid,))
    dproducts = cursor.fetchall()
    
    
    cursor.execute("select customerid, customername,phoneno,address from customersdetails where customerid=%s",(customerid,))
    dcustomers = cursor.fetchall()
    
    combined_data = [( dcustomer[0],dproduct[0], dproduct[1],dproduct[2], dcustomer[1],dcustomer[2],dcustomer[3]) for dproduct, dcustomer in zip(dproducts, dcustomers)]
    query = "INSERT INTO orders (customerid, productid, restuarant_id,productname,customername,customerphoneno,customeraddress ) VALUES (%s, %s, %s, %s,%s,%s,%s)"
    cursor.executemany(query, combined_data)
    db.commit()

    return "Order placed successfully!"


if __name__=='__main__':
    application.run(debug=True)
    
    
    application.run('0.0.0.0',7900)